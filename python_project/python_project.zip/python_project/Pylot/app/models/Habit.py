from system.core.model import Model

class Habit(Model):
    def __init__(self):
        super(Habit, self).__init__()
    def all(self):
        query = "SELECT * from users"
        return self.db.query_db(query)
    def show_habit_by_id(self, id):
        query = "SELECT * FROM habits WHERE id = :id;"
        data = {
            'id': id
        }
        return self.db.query_db(query, data)
    def show_habitname(self, id):
    	query  = "SELECT * FROM habits WHERE habit_id = :id;"
    	data = {
    		'id': id
    	}
    	return self.db.query_db(query, data)
