"""
    Sample Controller File

    A Controller should be in charge of responding to a request.
    Load models to interact with the database and load views to render them to the client.

    Create a controller using this template
"""
from system.core.controller import *

class Habits(Controller):
    def __init__(self, action):
        super(Habits, self).__init__(action)
        self.load_model('Habit')
        self.db = self._app.db
    def index(self):
        habits = self.models['Habit'].all()
        return self.load_view('index.html', habits=habits)
    def index_json(self):
        habits = self.models['Habit'].all()
        return jsonify(habits=habits)
    def show_habit(self, id):
        habits = self.models['Habits'].show_habitname(id)
        return self.load_view('/partials/habits.html', habits=habits)
