"""
    Sample Controller File

    A Controller should be in charge of responding to a request.
    Load models to interact with the database and load views to render them to the client.

    Create a controller using this template
"""
from system.core.controller import *
import random
import string



class Index(Controller):
    def __init__(self, action):
        super(Index, self).__init__(action)
        """
        This is an example of loading a model.
        Every controller has access to the load_model method.
        """
        self.load_model('WelcomeModel')
        self.db = self._app.db


        """
        
        This is an example of a controller method that will load a view for the client 

        """
    def index(self):
        session['attempt'] = 0
        return self.load_view('index.html')

    def randomword(self):
        session['attempt'] = session['attempt'] + 1
        chars = string.letters + string.digits
        randomphrase=''.join((random.choice(chars)) for x in range(14))

        return self.load_view('index.html', randomphrase=randomphrase, counter=session['attempt'])



