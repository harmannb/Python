from time import strftime
from system.core.controller import *


class Time_display(Controller):
    def __init__(self, action):
        super(Time_display, self).__init__(action)

    def index(self):
        time = strftime('%B %-d, %Y %-I:%M %p')
        return self.load_view('time_display.html', time=time)
