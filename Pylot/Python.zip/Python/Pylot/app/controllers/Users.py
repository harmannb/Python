from system.core.controller import *


class Users(Controller):
    def __init__(self, action):
        super(Users, self).__init__(action)
        self.load_model('User')
        self.load_model('Quote')

    # method to display registration page
    def index(self):
        users = self.models['User'].login_user()
        user = self.models['Quote'].get_user()
        quotes = self.models['Quote'].grab_quotes()
        return self.load_view('quote.html', users=users, quotes=quotes, user=user)

    def create(self):
        info = {"first_name": request.form['first_name'], "last_name": request.form['last_name'],
                "email": request.form['email'], "password": request.form['password'],
                "pw_confirmation": request.form['pw_confirmation']}
        new_user = self.models['User'].create_user(info)

        if new_user['status']:
            session['id'] = new_user['user']['id']
            session['first_name'] = new_user['user']['first_name']
            return redirect('/')
        else:
            for message in new_user['errors']:
                flash(message, 'regis_errors')
            return redirect('/')

    def login(self):
        info = {'email': request.form['email'], 'password': request.form['password']}
        user = self.models['User'].login_user(info)
        if user:
            print session['quotes']
            return redirect('/quotes')
        else:
            flash('incorrect')
            return redirect('/')

    def success(self):
        return self.load_view('quote.html')

