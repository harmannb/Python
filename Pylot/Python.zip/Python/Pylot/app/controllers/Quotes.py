from system.core.controller import *

class Quotes(Controller):
    def __init__(self, action):
        super(Quotes, self).__init__(action)
        self.load_model('Quote')
   
    def index(self):
        user = self.models['Quote'].get_user()
        quotes = self.models['Quote'].grab_quotes()
        return self.load_view('quote.html', user=user, quotes=quotes)

    def user(self, id):
        name = self.models['Quote'].get_user(id)
        return self.load_view('user.html', name=name[0])
