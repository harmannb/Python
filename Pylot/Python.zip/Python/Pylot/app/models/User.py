from system.core.model import *
from flask import Flask, flash
import re 


class User(Model):
    def __init__(self):
        super(User, self).__init__()

    def create_user(self, info):
        EMAIL_REGEX = re.compile(r'^[a-za-z0-9\.\+_-]+@[a-za-z0-9\._-]+\.[a-za-z]*$')
        errors = []
        if not info['first_name']:
            errors.append('First Name cannot be blank')
        elif len(info['first_name']) < 2:
            errors.append('Name must be at least 2 characters long')
        if not info['last_name']:
            errors.append('Last Name cannot be blank')
        elif len(info['last_name']) < 2:
            errors.append('Name must be at least 2 characters long')
        if not info['email']:
            errors.append('Email cannot be blank')
        elif not EMAIL_REGEX.match(info['email']):
            errors.append('Email format must be valid!')
        if not info['password']:
            errors.append('Password cannot be blank')
        elif len(info['password']) < 8:
            errors.append('Password must be at least 8 characters long')
        elif info['password'] != info['pw_confirmation']:
            errors.append('Password and confirmation must match!')
        if errors:
            return {"status": False, "errors": errors}
        else:
            hashed_pw = self.bcrypt.generate_password_hash(info['password'])
            create_query = 'INSERT INTO users (first_name, last_name, email, password, created_at) VALUES (:first_name, :last_name, :email, :password, NOW())'
            create_data = {'first_name': info['first_name'], 'last_name': info['last_name'], 'email': info['email'], 'password': hashed_pw}
            self.db.query_db(create_query, create_data)
            select_query = 'SELECT * FROM users WHERE email = :email LIMIT 1'
            select_data = {'email': info['email']}
            users = self.db.query_db(select_query, select_data)
            return {"status": True, "user": users[0]}

    def login_user(self, info):
        password = info['password']
        user_query = "SELECT * FROM users WHERE email = :email LIMIT 1"
        user_data = {'email': info['email']}
        user = self.db.get_one(user_query, user_data)
        if not user:
            flash('Incorrect Login')
            return False
        else:
            if self.bcrypt.check_password_hash(user.password, password):
                return user
            else:
                return False
