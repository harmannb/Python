from system.core.model import Model

class Quote(Model):
    def __init__(self):
        super(Quote, self).__init__()

    def get_users(self):
        query = "SELECT * from users"
        return self.db.query_db(query)

    def get_user(self, id):
        query = "SELECT * from users where id= :id"
        database = {'id': id}
        return self.db.query_db(query, database)

    def add_quote(self, info):
        query = "INSERT INTO quotes (quote, user_id, created_at) VALUES (:quote, :user_id, NOW())"
        data = {'quote': info['quote'], 'user_id': info['user_id']}
        return self.db.query_db(query, data)
    
    def grab_quote(self, info):
        query = "SELECT quotes.quote FROM users LEFT JOIN quotes ON users.id = quotes.user_id WHERE users.id = 1"
        data = {'quote': info['quote']}
        return self.db.query_db(query, data)

