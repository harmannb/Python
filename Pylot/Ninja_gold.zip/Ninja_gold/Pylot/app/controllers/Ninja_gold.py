"""
    Sample Controller File

    A Controller should be in charge of responding to a request.
    Load models to interact with the database and load views to render them to the client.

    Create a controller using this template
"""

from system.core.controller import *
import random

class Ninja_gold(Controller):
    def __init__(self, action):
        super(Ninja_gold, self).__init__(action)
        """
        This is an example of loading a model.
        Every controller has access to the load_model method.
        """
        self.load_model('WelcomeModel')
        self.db = self._app.db

        """
        
        This is an example of a controller method that will load a view for the client 

        """
   
    def index(self):
        return self.load_view('index.html')
        """
        A loaded model is accessible through the models attribute 
        self.models['WelcomeModel'].get_users()
        
        self.models['WelcomeModel'].add_message()
        # messages = self.models['WelcomeModel'].grab_messages()
        # user = self.models['WelcomeModel'].get_user()
        # to pass information on to a view it's the same as it was with Flask
        
        # return self.load_view('index.html', messages=messages, user=user)
        """
        

    def process_money(self):

        if request.form['building'] == 'farm':
            farmNum = random.randint(10,20)
            session['total'] += farmNum
            session['activity'].insert(0,"Earned " + str(farmNum)+ " from the farm!" + "\n")
            print session['activity']

        elif request.form['building'] == 'cave':
            caveNum = random.randint(5,10)
            session['total'] += caveNum
            session['activity'].insert(0,"Earned " + str(caveNum)+ " from the cave!" + "\n")
    
        elif request.form['building'] == 'house':
            houseNum = random.randint(2,5)
            session['total'] += houseNum
            session['activity'].insert(0,"Earned " + str(houseNum)+ " from the house!" + "\n")

        elif request.form['building'] == 'casino':
            casinoNum = random.randint(-50,50)
            session['total'] += casinoNum
            session['activity'].insert(0,"Earned " + str(casinoNum)+ " from the casino!" + "\n")

        return redirect('/')


    def reset(self):
        session['total'] = 0
        session['activity'] = []
        return redirect('/')
